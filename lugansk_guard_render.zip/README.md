# Lugansk Guard Bot для Render

## Як запустити:

1. Завантаж проект на GitHub
2. Створи новий Web Service на https://render.com
3. Обери Python версію 3.10+
4. Додай змінну середовища BOT_TOKEN з токеном бота
5. Готово! Бот буде працювати 24/7
